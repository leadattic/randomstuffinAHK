i = 1
while 1 == 1:
    i = i * 2
    print('\n number: ' + str(i))
